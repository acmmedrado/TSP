# TSP-MPI
Solving the travelling salesman problem in a HPC setting by using genetic algorithm parallellized with MPI; implemented in C.

# Usage
## Compilation
See [compilation instructions](src/README).

## Usage
See [run instructions](src/README)

# License
The source code from this project is subject to the terms of the GNU Affero General Public License version 3 (AGPLv3). A copy of the AGPLv3 license is supplied with the project, or can be obtained at [https://opensource.org/licenses/AGPL-3.0](https://opensource.org/licenses/AGPL-3.0).

